package fiap;

import javax.swing.JOptionPane;

public class UsaCalculadora {
	public static void main(String[] args) {
		Calculadora mat = new Calculadora();
		float numero1,numero2;
		String aux, continuar = "sim";
		int menu;
		
		while (continuar.equalsIgnoreCase("sim")) {
			try {
				aux = JOptionPane.showInputDialog("DIgite o primeio números: ");
				numero1 = Float.parseFloat(aux);
				aux = JOptionPane.showInputDialog("Digite o segundo número: ");
				numero2 = Float.parseFloat(aux);
				aux = JOptionPane.showInputDialog("qual operação deseja realizar: \n(1) Adição \n(2) Subtração \n(3) Multiplicação \n(4) Divisão");
				menu = Integer.parseInt(aux);
				mat.setNumero1(numero1);
				mat.setNumero2(numero2);
				switch (menu) {
				case 1:
					JOptionPane.showMessageDialog(null, "Resultado: " + mat.adicao());
					break;
				case 2:
					JOptionPane.showMessageDialog(null, "Resultado: " + mat.subtracao());
					break;
				case 3:
					JOptionPane.showMessageDialog(null, "Resultado: " + mat.multiplicacao());
					break;
				case 4:
					JOptionPane.showMessageDialog(null, "Resultado: " + mat.divisao());
					break;
					
				default:
					break;
				}
			} catch (ArrayIndexOutOfBoundsException e) {
				System.out.println(e.getMessage());
			} catch (ArithmeticException e) {
				System.out.println(e.getMessage());
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			continuar = JOptionPane.showInputDialog("deseja fazer outra conta: (sim - não)");
			
		}
		JOptionPane.showMessageDialog(null, "fim de programa");
	}
}
