package fiap;

public class Calculadora {
	private float numero1;
	private float numero2;

	public Calculadora() {

	}

	public float getNumero1() {
		return numero1;
	}

	public void setNumero1(float numero1) {
		this.numero1 = numero1;
	}

	public float getNumero2() {
		return numero2;
	}

	public void setNumero2(float numero2) {
		this.numero2 = numero2;
	}
	public float adicao() {
		float resultado;
		resultado = numero1 + numero2;
		return resultado;
	}
	public float subtracao() {
		float resultado;
		resultado = numero1 - numero2;
		return resultado;
	}
	public float divisao() throws ArithmeticException {
		float resultado;
			if (this.numero2 != 0) {
				resultado = numero1 / numero2;
			} else {
				throw new ArithmeticException("Não pode dividir por zero");
			}
		return resultado;
	}
	public float multiplicacao() {
		float resultado;
		resultado = numero1 * numero2;
		return resultado;
	}

}
